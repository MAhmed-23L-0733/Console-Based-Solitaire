#include <iostream>
#include "DLL.cpp"
using namespace std;
template <class T>
class stack
{
private:
    DLL<T> stk;

public:
    void push(const T &data)
    {
        stk.AddToEnd(data);
    }
    bool isEmpty()
    {
        return stk.IsEmpty();
    }
    T pop()
    {
        T data;
        if (!stk.IsEmpty())
        {

            data = stk.GetLastNode()->data;
            stk.DeleteTop();
            return data;
        }
        else
        {
            return data;
        }
    }
    T &top()
    {
        return stk.GetLastNode()->data;
    }
    int size()
    {
        if (stk.IsEmpty())
        {
            return 0;
        }
        return stk.Length();
    }
};