#include <iostream>
#include <cstring>
#include <cstdlib>
#include <windows.h>
#include <time.h>
#include <conio.h>
#include "Game.cpp"
using namespace std;
int main()
{
    SetConsoleOutputCP(CP_UTF8);
    Game game;
    game.run();
    return 0;
}