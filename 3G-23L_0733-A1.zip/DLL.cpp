#include <iostream>
using namespace std;
template <class T>
class DLL
{
private:
    struct node;

    node *head;
    node *tail;

public:
    class ListIterator;
    typedef ListIterator Iterator;
    DLL()
    {
        head = new node[1];
        tail = new node[1];
        head->next = tail;
        tail->prev = head;
    }
    ~DLL()
    {
        node *start = head;
        node *temp;
        while (start != 0)
        {
            temp = start;
            start = start->next;
            delete temp;
        }
    }
    void Print()
    {
        Iterator i(head->next);
        while (i != tail)
        {
            cout << *i << " ";
            ++i;
        }
    }
    void AddToEnd(const T &value)
    {
        node *temp = tail->prev;
        tail->prev = new node(value);
        tail->prev->next = tail;
        tail->prev->prev = temp;
        temp->next = tail->prev;
    }
    void DeleteNode(node *&n)
    {
        node *temp1 = n->next;
        node *temp2 = n->prev;
        delete n;
        temp1->prev = temp2;
        temp2->next = temp1;
        n = temp2;
    }
    void DeleteTop()
    {
        if (this->IsEmpty())
        {
            return;
        }
        DeleteNode(tail->prev);
    }
    T GetTop()
    {
        return tail->prev->data;
    }
    bool IsEmpty()
    {
        if (head->next == tail)
        {
            return true;
        }
        return false;
    }
    node *FindNode(int n)
    {
        node *dummy = nullptr;
        if (n > this->Length())
        {
            cerr << "Out of Bound!" << endl;
            return dummy;
        }
        Iterator i(head->next);
        int j = 0;
        while (i != tail)
        {
            if (j == n)
            {
                return i.iptr;
            }
            j++;
            ++i;
        }
        return dummy;
    }
    node *GetLastNode()
    {
        return tail->prev;
    }
    bool DoesContain(T data)
    {
        Iterator i(head->next);
        while (i != tail)
        {
            if (data == *i)
            {
                return true;
            }
            ++i;
        }
        return false;
    }
    int Length()
    {
        int length = 0;
        if (this->head == nullptr)
        {
            return 0;
        }
        Iterator i(head->next);
        while (i != tail)
        {
            length++;
            ++i;
        }
        return length;
    }
    void print(int n = 0)
    {
        if (n >= this->Length())
        {
            cout << "  \t\t"; // necessary adjustments so that it looks good :)
            return;
        }
        else
        {
            Iterator i(head->next);
            int j = 0;
            while (i != tail)
            {
                if (j == n)
                {
                    cout << *i << "\t\t"; // a little here as well :)
                    return;
                }
                j++;
                ++i;
            }
        }
    }
    T GetNode(int n = 0)
    {
        T data;
        if (n > this->Length() || n < 0)
        {
            cerr << "Out of Bound!" << endl;
            return data;
        }
        Iterator i(head->next);
        int j = 0;
        while (i != tail)
        {
            if (j == n)
            {
                return *i;
            }
            j++;
            ++i;
        }
        return data;
    }
};
template <class T>
class DLL<T>::ListIterator
{
private:
    node *iptr;

public:
    friend class DLL;
    ListIterator(node *n = nullptr)
    {
        iptr = n;
    }
    // operators
    ListIterator &operator++()
    {
        if (iptr)
        {
            iptr = iptr->next;
        }
        return *this;
    }
    T &operator*()
    {
        return iptr->data;
    }
    bool operator==(const ListIterator &L) const
    {
        return (iptr->data == L.iptr->data);
    }
    bool operator!=(const ListIterator &L) const
    {

        return (iptr != L.iptr);
    }
    bool operator!=(node *&n) const
    {

        return (iptr != n);
    }
};
template <class T>
struct DLL<T>::node
{
    node *next;
    node *prev;
    T data;
    node()
    {
        next = 0;
        prev = 0;
    }
    node(T d, node *n = 0, node *p = 0)
    {
        data = d;
        next = n;
        prev = p;
    }
};