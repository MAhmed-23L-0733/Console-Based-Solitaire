#include <iostream>
#include <conio.h>
using namespace std;
class Card
{
private:
    char symbol;
    char value;
    char colour;
    bool face;

public:
    bool operator==(const Card &C)
    {
        return (this == &C);
    }
    static char CardValues[13];
    Card()
    {
        value = 0;
        symbol = '0';
        colour = '0';
        face = false;
    }
    void Set(char symbol, int i, char colour)
    {
        this->symbol = symbol;
        this->value = CardValues[i];
        this->colour = colour;
    }
    void TurnFace() // this function toggles the face up or down on calling
    {
        this->face = !this->face;
    }
    string Symbol() // makeup function
    {
        if (symbol == 'H')
            return "\u2665";
        if (symbol == 'S')
            return "\u2660";
        if (symbol == 'C')
            return "\u2663";
        if (symbol == 'D')
            return "\u2666";
        return "";
    }
    void print()
    {
        HANDLE hc = GetStdHandle(STD_OUTPUT_HANDLE);
        if (this->face)
        {
            if (this->colour == 'r')
            {
                SetConsoleTextAttribute(hc, 0x04);
                if (this->value == 'T')
                    cout << "10" << this->Symbol();
                else
                    cout << value << this->Symbol();
                SetConsoleTextAttribute(hc, 0x07);
            }
            else
            {
                if (this->value == 'T')
                    cout << "10" << this->Symbol();
                else
                    cout << value << this->Symbol();
            }
        }
        else
        {
            SetConsoleTextAttribute(hc, 0x08);
            cout << "[ ]";
            SetConsoleTextAttribute(hc, 0x07);
        }
    }
    friend ostream &operator<<(ostream &cout, Card C)
    {
        C.print();
        return cout;
    }
    int GetRank()
    {
        int i = 0;
        for (i = 0; i < 13; i++)
        {
            if (value == CardValues[i])
            {
                return i;
            }
        }
        return -1;
    }
    int GetColour()
    {
        return colour;
    }
    char GetSymbol()
    {
        return symbol;
    }
    bool Face()
    {
        if (face)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
};
// hard coded the values as they remain fixed throughout the game and made it static
char Card::CardValues[13] = {'A', '2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K'};