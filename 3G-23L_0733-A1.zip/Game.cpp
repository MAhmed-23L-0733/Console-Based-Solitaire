#include <iostream>
#include <cstring>
#include <conio.h>
#include "Stack.cpp"
#include "Card.cpp"
using namespace std;
const int max_cols = 7;
class Game
{
private:
    Card *cards;
    stack<Card> stockPile;
    stack<Card> wastePile;
    stack<Card> FPile1;
    stack<Card> FPile2;
    stack<Card> FPile3;
    stack<Card> FPile4;
    stack<string> undo;
    DLL<Card> *columns;
    int difficulty;
    int UndoCount;

public:
    Game()
    {
        cards = new Card[52];
        columns = new DLL<Card>[7];
    }
    ~Game()
    {
        delete[] cards;
        delete[] columns;
    }
    void LoadCards()
    {
        HANDLE hc = GetStdHandle(STD_OUTPUT_HANDLE);
        int index = 0;
        int choice;
        cout << "\n\n\t--> Solitaire <--" << endl;
        cout << "\n\nChoose Difficulty: (`0 w 0')\n";
        SetConsoleTextAttribute(hc, 0x02);
        cout << "\n1. Ez\n";
        SetConsoleTextAttribute(hc, 0x04);
        cout << "2. Hard";
        SetConsoleTextAttribute(hc, 0x07);
        cout << "\n\nChoice -> ";
        cin >> difficulty;
        while (cin.fail())
        {
            cin.clear();
            cin.ignore();
            cout << "\nChoose Wisely Or I will start it in Hard! (`M w M')" << endl;
            cout << "\nChoice --> ";
            cin >> difficulty;
        }
        // intializing all cards with their symbols , colours and value
        // r = red , b = black
        // s = spades , h = hearts , d = diamonds , c = clubs
        for (int i = 0; i < 13; i++)
        {
            cards[index].Set('H', i, 'r');
            index++;
        }
        for (int i = 0; i < 13; i++)
        {
            cards[index].Set('S', i, 'b');
            index++;
        }
        for (int i = 0; i < 13; i++)
        {
            cards[index].Set('C', i, 'b');
            index++;
        }
        for (int i = 0; i < 13; i++)
        {
            cards[index].Set('D', i, 'r');
            index++;
        }
    }
    void Initialize()
    {
        int random;
        srand(time(0));
        DLL<int> indecies;
        // initializing columns
        for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j <= i; j++)
            {
                random = rand() % 51;
                while (indecies.DoesContain(random))
                {
                    random = rand() & 51;
                }
                if (j == i)
                {
                    cards[random].TurnFace();
                }
                columns[i].AddToEnd(cards[random]);
                indecies.AddToEnd(random);
            }
        }
        // pushing remaining cards in the stock pile
        for (int i = 0; i < 52; i++)
        {
            if (!indecies.DoesContain(i))
                stockPile.push(cards[i]);
        }
    }
    void Load()
    {
        LoadCards();
        Initialize();
    }
    void Display()
    {
        HANDLE hc = GetStdHandle(STD_OUTPUT_HANDLE);
        SetConsoleTextAttribute(hc, 0x03);
        cout << "\nStock\t\tWaste\t\t";
        SetConsoleTextAttribute(hc, 0x04);
        cout << "F\u2665";
        SetConsoleTextAttribute(hc, 0x07);
        cout << "\t\tF\u2663\t\t";
        SetConsoleTextAttribute(hc, 0x04);
        cout << "F\u2666";
        SetConsoleTextAttribute(hc, 0x07);
        cout << "\t\tF\u2660 " << endl;
        SetConsoleTextAttribute(hc, 0x08);
        cout << "[ ]";
        SetConsoleTextAttribute(hc, 0x07);
        cout << "\t\t" << wastePile.top() << "\t\t" << FPile1.top() << "\t\t" << FPile2.top() << "\t\t" << FPile3.top() << "\t\t" << FPile4.top() << endl;
        SetConsoleTextAttribute(hc, 0x0A);
        cout << "(" << stockPile.size() << " cards)\t" << "(" << wastePile.size() << " cards)\t" << "(" << FPile1.size() << " cards)\t" << "(" << FPile2.size() << " cards)\t" << "(" << FPile3.size() << " cards)\t" << "(" << FPile4.size() << " cards)" << endl;
        SetConsoleTextAttribute(hc, 0x07);
        cout << "\n----------------------------------------------------------------------------------------------------";
        SetConsoleTextAttribute(hc, 0x0E);
        cout << "\n\nC1\t\tC2\t\tC3\t\tC4\t\tC5\t\tC6\t\tC7" << endl;
        SetConsoleTextAttribute(hc, 0x0A);
        for (int i = 0; i < 7; i++)
        {

            cout << "(" << columns[i].Length() << " cards)      ";
        }
        SetConsoleTextAttribute(hc, 0x07);
        cout << endl;
        int max_len = 0;
        for (int i = 0; i < 7; i++) // calculating which list has the max length
        {
            if (max_len < columns[i].Length())
            {
                max_len = columns[i].Length();
            }
        }
        for (int i = 0; i < max_len; i++)
        {
            for (int j = 0; j < 7; j++)
            {
                columns[j].print(i); // prints the ith elemtent of the list
            }
            cout << endl;
        }
    }
    void MoveCards(int &source, int &dest, int &number, bool &invalid, bool &face)
    {
        int rankDest = 0, rankSource = 0;
        dest -= 1;
        source -= 1;
        int i = columns[source].Length() - number;
        if (columns[source].IsEmpty())
        {
            cerr << "Empty Column!" << endl;
            invalid == true;
            return;
        }
        if (columns[dest].IsEmpty() && columns[source].GetNode(i).GetRank() != 12)
        {
            cerr << "Only King can be moved to an empty column!" << endl;
            invalid == true;
            return;
        }
        if (columns[dest].IsEmpty())
        {
            rankDest = 13;
        }
        else
        {
            rankDest = columns[dest].GetTop().GetRank();
        }
        rankSource = columns[source].GetNode(i).GetRank();
        if (!columns[source].GetNode(i).Face())
        {
            cerr << "Card face is turned!" << endl;
            invalid = true;
            return;
        }
        else if (rankSource >= rankDest || rankSource != rankDest - 1)
        {
            cerr << "Rank Mismatch!" << endl;
            invalid = true;
            return;
        }
        else if (columns[dest].GetTop().GetColour() == columns[source].GetNode(i).GetColour() && difficulty != 1)
        {
            cerr << "Same colour cards!" << endl;
            invalid = true;
            return;
        }
        else if (columns[dest].IsEmpty() && rankSource != 12)
        {
            cout << "Only King can be moved to an empty column!" << endl;
            invalid = true;
            return;
        }
        else
        {
            DLL<Card> temp;
            for (int j = 0; j < number; j++)
            {
                temp.AddToEnd(columns[source].GetTop());
                columns[source].DeleteTop();
            }
            face = columns[source].GetLastNode()->data.Face();
            if (!columns[source].GetTop().Face())
                columns[source].GetLastNode()->data.TurnFace();
            for (int i = 0; i < number; i++)
            {
                columns[dest].AddToEnd(temp.GetTop());
                temp.DeleteTop();
            }
        }
    }
    void MovFoundation(int n, int &source, bool &invalid, bool &face)
    {
        source -= 1;
        int rankFpile;
        if (n == 4)
        {
            if (FPile1.isEmpty())
            {
                rankFpile = -1;
            }
            else
                rankFpile = FPile1.top().GetRank();
            if (columns[source].GetLastNode()->data.GetSymbol() != 'H')
            {
                cerr << "Suit Mismatch!" << endl;
                invalid = true;
                return;
            }
            else if (rankFpile != columns[source].GetLastNode()->data.GetRank() - 1)
            {
                cerr << "Rank Mismatch!" << endl;
                invalid = true;
                return;
            }
            else
            {
                FPile1.push(columns[source].GetLastNode()->data);
                columns[source].DeleteTop();
                face = columns[source].GetTop().Face();
                if (!columns[source].GetLastNode()->data.Face())
                    columns[source].GetLastNode()->data.TurnFace();
            }
        }
        if (n == 5)
        {
            if (FPile2.isEmpty())
            {
                rankFpile = -1;
            }
            else
                rankFpile = FPile2.top().GetRank();
            if (columns[source].GetLastNode()->data.GetSymbol() != 'C')
            {
                cerr << "Suit Mismatch!" << endl;
                invalid = true;
                return;
            }
            else if (rankFpile != columns[source].GetLastNode()->data.GetRank() - 1)
            {
                cerr << "Rank Mismatch!" << endl;
                invalid = true;
                return;
            }
            else
            {
                FPile2.push(columns[source].GetLastNode()->data);
                columns[source].DeleteTop();
                face = columns[source].GetTop().Face();
                if (!columns[source].GetLastNode()->data.Face())
                    columns[source].GetLastNode()->data.TurnFace();
            }
        }
        if (n == 6)
        {
            if (FPile3.isEmpty())
            {
                rankFpile = -1;
            }
            else
                rankFpile = FPile3.top().GetRank();
            if (columns[source].GetLastNode()->data.GetSymbol() != 'D')
            {
                cerr << "Suit Mismatch!" << endl;
                invalid = true;
                return;
            }
            else if (rankFpile != columns[source].GetLastNode()->data.GetRank() - 1)
            {
                cerr << "Rank Mismatch!" << endl;
                invalid = true;
                return;
            }
            else
            {
                FPile3.push(columns[source].GetLastNode()->data);
                columns[source].DeleteTop();
                face = columns[source].GetTop().Face();
                if (!columns[source].GetLastNode()->data.Face())
                    columns[source].GetLastNode()->data.TurnFace();
            }
        }
        if (n == 7)
        {
            if (FPile4.isEmpty())
            {
                rankFpile = -1;
            }
            else
                rankFpile = FPile4.top().GetRank();
            if (columns[source].GetLastNode()->data.GetSymbol() != 'S')
            {
                cerr << "Suit Mismatch!" << endl;
                invalid = true;
                return;
            }
            else if (rankFpile != columns[source].GetLastNode()->data.GetRank() - 1)
            {
                cerr << "Rank Mismatch!" << endl;
                invalid = true;
                return;
            }
            else
            {
                FPile4.push(columns[source].GetLastNode()->data);
                columns[source].DeleteTop();
                face = columns[source].GetTop().Face();
                if (!columns[source].GetLastNode()->data.Face())
                    columns[source].GetLastNode()->data.TurnFace();
            }
        }
    }
    int CheckCommand(string s, int &source, int &dest, int &number)
    {
        int i = 0;
        if (s[0] == 's')
        {
            return 1;
        }
        else if (s[0] == 'z')
        {
            return 2;
        }
        else if (s[0] == 'm')
        {
            i++;
            while (s[i] != '\0')
            {
                if (s[i] == 'w')
                {
                    dest = -2;
                    number = -2;
                    int n = i;
                    while (s[n] != '\0')
                    {
                        if (s[n] == 'f' && (s[n + 1] >= '0' && s[n + 1] <= '9'))
                        {
                            return (s[n + 1] - 48) + 8;
                        }
                        n++;
                    }
                }
                else if (s[i] == 'c' && source == -1)
                {
                    if (s[i + 1] >= '0' && s[i + 1] <= '9')
                    {
                        source = s[i + 1] - 48;
                        i++;
                        if (dest == -2)
                        {
                            return 8;
                        }
                    }
                    else
                    {
                        return -1;
                    }
                }
                else if (s[i] == 'c' && dest == -1)
                {
                    if (s[i + 1] >= '0' && s[i + 1] <= '9')
                    {
                        dest = s[i + 1] - 48;
                        i++;
                    }
                    else
                    {
                        return -1;
                    }
                }
                else if (s[i] >= '0' && s[i] <= '9' && number == -1)
                {
                    if (s[i + 1] >= '0' && s[i + 1] <= '9')
                    {
                        number = (s[i] - 48) * 10;
                        number += s[i + 1] - 48;
                    }
                    else
                    {
                        number = s[i] - 48;
                    }
                }
                else if (s[i] == 'f')
                {
                    if (s[i + 1] == '1')
                    {
                        if (source == -1)
                        {
                            int n = i;
                            while (s[n] != '\0')
                            {
                                if (s[n] == 'c' && (s[n + 1] >= '0' && s[n + 1] <= '9'))
                                {
                                    source = s[n + 1] - 48;
                                    return (s[i + 1] - 48) + 12;
                                }
                                n++;
                            }
                            return -1;
                        }
                        return 4;
                    }
                    else if (s[i + 1] == '2')
                    {
                        if (source == -1)
                        {
                            int n = i;
                            while (s[n] != '\0')
                            {
                                if (s[n] == 'c' && (s[n + 1] >= '0' && s[n + 1] <= '9'))
                                {
                                    source = s[n + 1] - 48;
                                    return (s[i + 1] - 48) + 12;
                                }
                                n++;
                            }
                            return -1;
                        }
                        return 5;
                    }
                    else if (s[i + 1] == '3')
                    {
                        if (source == -1)
                        {
                            int n = i;
                            while (s[n] != '\0')
                            {
                                if (s[n] == 'c' && (s[n + 1] >= '0' && s[n + 1] <= '9'))
                                {
                                    source = s[n + 1] - 48;
                                    return (s[i + 1] - 48) + 12;
                                }
                                n++;
                            }
                            return -1;
                        }
                        return 6;
                    }
                    else if (s[i + 1] == '4')
                    {
                        if (source == -1)
                        {
                            int n = i;
                            while (s[n] != '\0')
                            {
                                if (s[n] == 'c' && (s[n + 1] >= '0' && s[n + 1] <= '9'))
                                {
                                    source = s[n + 1] - 48;
                                    return (s[i + 1] - 48) + 12;
                                }
                                n++;
                            }
                            return -1;
                        }
                        return 7;
                    }
                    else
                    {
                        return -1;
                    }
                }
                i++;
            }
            if (number == -1 || source == -1 || dest == -1)
            {
                return -1;
            }
            else
            {
                return 3;
            }
        }
        else
        {
            return -1;
        }
    }
    void DrawCard()
    {
        if (stockPile.isEmpty())
        {
            while (!wastePile.isEmpty())
            {
                stockPile.push(wastePile.pop());
                stockPile.top().TurnFace();
            }
        }
        else
        {
            wastePile.push(stockPile.pop());
            wastePile.top().TurnFace();
        }
    }
    void MoveWasteToCol(int &source, bool &invalid)
    {
        source -= 1;
        if ((wastePile.top().GetRank() != columns[source].GetLastNode()->data.GetRank() - 1) && columns[source].IsEmpty() == false)
        {
            cerr << "Rank Mismatch!" << endl;
            invalid = false;
            return;
        }
        else if (columns[source].IsEmpty() && wastePile.top().GetRank() != 12)
        {
            cout << "Only King can be moved to an empty column!" << endl;
            invalid = true;
            return;
        }
        else
        {

            columns[source].AddToEnd(wastePile.pop());
        }
    }
    void MoveWasteToFoundation(int n, bool &invalid)
    {
        if (n == 9)
        {
            if (wastePile.top().GetSymbol() != 'H')
            {
                cerr << "Suit Mismatch!" << endl;
                invalid = true;
                return;
            }
            else if (wastePile.top().GetRank() != FPile1.top().GetRank() + 1)
            {
                cerr << "Rank Mismatch!" << endl;
                invalid = true;
                return;
            }
            else
            {
                FPile1.push(wastePile.pop());
            }
        }
        if (n == 10)
        {
            if (wastePile.top().GetSymbol() != 'C')
            {
                cerr << "Suit Mismatch!" << endl;
                invalid = true;
                return;
            }
            else if (wastePile.top().GetRank() != FPile2.top().GetRank() + 1)
            {
                cerr << "Rank Mismatch!" << endl;
                invalid = true;
                return;
            }
            else
            {
                FPile2.push(wastePile.pop());
            }
        }
        if (n == 11)
        {
            if (wastePile.top().GetSymbol() != 'D')
            {
                cerr << "Suit Mismatch!" << endl;
                invalid = true;
                return;
            }
            else if (wastePile.top().GetRank() != FPile3.top().GetRank() + 1)
            {
                cerr << "Rank Mismatch!" << endl;
                invalid = true;
                return;
            }
            else
            {
                FPile3.push(wastePile.pop());
            }
        }
        if (n == 12)
        {
            if (wastePile.top().GetSymbol() != 'S')
            {
                cerr << "Suit Mismatch!" << endl;
                invalid = true;
                return;
            }
            else if (wastePile.top().GetRank() != FPile4.top().GetRank() + 1)
            {
                cerr << "Rank Mismatch!" << endl;
                invalid = true;
                return;
            }
            else
            {
                FPile4.push(wastePile.pop());
            }
        }
    }
    void MovFoundationToCol(int n, int source, bool &invalid)
    {
        source -= 1;
        if (n == 13)
        {
            if (columns[source].GetLastNode()->data.GetSymbol() != 'H')
            {
                cerr << "Suit MisMatch!" << endl;
                invalid = true;
                return;
            }
            else if (FPile1.top().GetRank() != columns[source].GetLastNode()->data.GetRank() - 1)
            {
                cerr << "Rank MisMatch!" << endl;
                invalid = true;
                return;
            }
            else
            {
                columns[source].AddToEnd(FPile1.pop());
            }
        }
        if (n == 14)
        {
            if (columns[source].GetLastNode()->data.GetSymbol() != 'H')
            {
                cerr << "Suit MisMatch!" << endl;
                invalid = true;
                return;
            }
            if (FPile2.top().GetRank() != columns[source].GetLastNode()->data.GetRank() - 1)
            {
                cerr << "Rank MisMatch!" << endl;
                invalid = true;
                return;
            }
            else
            {
                columns[source].AddToEnd(FPile2.pop());
            }
        }
        if (n == 15)
        {
            if (columns[source].GetLastNode()->data.GetSymbol() != 'H')
            {
                cerr << "Suit MisMatch!" << endl;
                invalid = true;
                return;
            }
            else if (FPile3.top().GetRank() != columns[source].GetLastNode()->data.GetRank() - 1)
            {
                cerr << "Rank MisMatch!" << endl;
                invalid = true;
                return;
            }
            else
            {
                columns[source].AddToEnd(FPile3.pop());
            }
        }
        if (n == 16)
        {
            if (columns[source].GetLastNode()->data.GetSymbol() != 'H')
            {
                cerr << "Suit MisMatch!" << endl;
                invalid = true;
                return;
            }
            else if (FPile4.top().GetRank() != columns[source].GetLastNode()->data.GetRank() - 1)
            {
                cerr << "Rank MisMatch!" << endl;
                invalid = true;
                return;
            }
            else
            {
                columns[source].AddToEnd(FPile4.pop());
            }
        }
    }
    void Undo(int &n, int &source, int &dest, int &number, string &s)
    {
        source -= 1;
        dest -= 1;
        if (n == 1)
        {
            stockPile.push(wastePile.pop());
            stockPile.top().TurnFace();
        }
        else if (n == 3)
        {
            int temporary = source;
            source = dest;
            dest = temporary;
            DLL<Card> temp;
            for (int j = 0; j < number; j++)
            {
                temp.AddToEnd(columns[source].GetTop());
                columns[source].DeleteTop();
            }
            int i = 0;
            while (s[i + 1] != '\0')
            {
                i++;
            }
            if (s[i] == '0')
                columns[dest].GetLastNode()->data.TurnFace();
            for (int i = 0; i < number; i++)
            {
                columns[dest].AddToEnd(temp.GetTop());
                temp.DeleteTop();
            }
        }
        else if (n == 4 || n == 5 || n == 6 || n == 7)
        {
            if (n == 4)
            {
                int i = 0;
                while (s[i + 1] != '\0')
                {
                    i++;
                }
                if (s[i] == '0')
                    columns[source].GetLastNode()->data.TurnFace();
                columns[source].AddToEnd(FPile1.pop());
            }

            if (n == 5)
            {
                int i = 0;
                while (s[i + 1] != '\0')
                {
                    i++;
                }
                if (s[i] == '0')
                    columns[source].GetLastNode()->data.TurnFace();
                columns[source].AddToEnd(FPile2.pop());
            }
            if (n == 6)
            {
                int i = 0;
                while (s[i + 1] != '\0')
                {
                    i++;
                }
                if (s[i] == '0')
                    columns[source].GetLastNode()->data.TurnFace();
                columns[source].AddToEnd(FPile3.pop());
            }
            if (n == 7)
            {
                int i = 0;
                while (s[i + 1] != '\0')
                {
                    i++;
                }
                if (s[i] == '0')
                    columns[source].GetLastNode()->data.TurnFace();
                columns[source].AddToEnd(FPile4.pop());
            }
        }
        else if (n == 8)
        {
            wastePile.push(columns[source].GetTop());
            columns[source].DeleteTop();
        }
        else if (n == 9 || n == 10 || n == 11 || n == 12)
        {
            if (n == 9)
                wastePile.push(FPile1.pop());
            if (n == 10)
                wastePile.push(FPile2.pop());
            if (n == 11)
                wastePile.push(FPile3.pop());
            if (n == 12)
                wastePile.push(FPile4.pop());
        }
        else if (n == 13 || n == 14 || n == 15 || n == 16)
        {
            if (n == 13)
            {
                FPile1.push(columns[source].GetTop());
                columns[source].DeleteTop();
            }
            if (n == 14)
            {
                FPile2.push(columns[source].GetTop());
                columns[source].DeleteTop();
            }
            if (n == 15)
            {
                FPile3.push(columns[source].GetTop());
                columns[source].DeleteTop();
            }
            if (n == 16)
            {
                FPile4.push(columns[source].GetTop());
                columns[source].DeleteTop();
            }
        }
    }
    void exe(string s)
    {
        display_clear();
        int source = -1, dest = -1, number = -1;
        int n = CheckCommand(s, source, dest, number);
        bool invalid = false;
        if (n == -1)
        {
            cerr << "Invalid Command! :<" << endl;
            return;
        }
        else if (n == 1)
        {
            UndoCount = 0;
            DrawCard();
            undo.push(s);
        }
        else if (n == 2)
        {
            if (undo.isEmpty())
            {
                cerr << "Cannot Undo Further!" << endl;
                return;
            }
            if (difficulty == 1 && UndoCount == 10)
            {
                cerr << "Cannot Undo Further!" << endl;
                return;
            }
            if (difficulty == 2 && UndoCount == 5)
            {
                cerr << "Cannot Undo Further" << endl;
                return;
            }
            string temp = undo.pop();
            n = CheckCommand(temp, source, dest, number);
            Undo(n, source, dest, number, temp);
            UndoCount++;
        }
        else if (n == 3)
        {
            bool face;
            MoveCards(source, dest, number, invalid, face);
            if (!invalid)
            {
                UndoCount = 0;
                if (face)
                {
                    s = s + ' ';
                    s = s + '1';
                }
                else
                {
                    s = s + ' ';
                    s = s + '0';
                }
                undo.push(s);
            }
        }
        else if (n == 4 || n == 5 || n == 6 || n == 7)
        {
            bool face;
            MovFoundation(n, source, invalid, face);
            if (!invalid)
            {
                UndoCount = 0;
                if (face)
                {
                    s = s + ' ';
                    s = s + '1';
                }
                else
                {
                    s = s + ' ';
                    s = s + '0';
                }
                undo.push(s);
            }
        }
        else if (n == 8)
        {
            MoveWasteToCol(source, invalid);
            if (!invalid)
            {
                UndoCount = 0;
                undo.push(s);
            }
        }
        else if (n == 9 || n == 10 || n == 11 || n == 12)
        {
            MoveWasteToFoundation(n, invalid);
            if (!invalid)
            {
                UndoCount = 0;
                undo.push(s);
            }
        }
        else if (n == 13 || n == 14 || n == 15 || n == 16)
        {
            MovFoundationToCol(n, source, invalid);
            if (!invalid)
            {
                UndoCount = 0;
                undo.push(s);
            }
        }
    }
    void display_clear()
    {
#ifdef _WIN32
        system("cls");
#else
        system("clear");
#endif
    }
    void wincheck()
    {
        if (FPile1.top().GetRank() == 12 && FPile2.top().GetRank() == 12 && FPile3.top().GetRank() == 12 && FPile4.top().GetRank() == 12)
        {
            cout << "You win! Congratulations!" << endl;
            exit(0);
        }
    }
    void run()
    {
        display_clear();
        string s;
        this->Load();
        while (true)
        {
            display_clear();
            this->Display();
            cout << "\n\nEnter Command --> ";
            getline(cin, s);
            exe(s);
            wincheck();
        }
    }
};